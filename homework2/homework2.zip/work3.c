#include <stdio.h>

int main()
{
	printf(""
	"JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ\n"
	"JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ\n"
	"             JJJJ             \n"
    "             JJJJ             \n"
    "             JJJJ             \n"
    "             JJJJ             \n"
    "             JJJJ             \n"
	"  JJJ        JJJJ             \n"
	"   JJJ       JJJJ             \n"
	"    JJJ      JJJJ             \n"
	"     JJJ     JJJJ             \n"
	"      JJJJ   JJJJ             \n"
	"        JJJJJJJJJ             \n"
	"          JJJJJJ              \n"
	"\n");

	printf(""
	"     LLLL                     \n"
	"     LLLL                     \n"
	"     LLLL                     \n"
	"     LLLL                     \n"
	"     LLLL                     \n"
	"     LLLL                     \n"
	"     LLLL                     \n"
	"     LLLL                     \n"
	"     LLLL                     \n"
	"     LLLL                     \n"
	"     LLLL                     \n"
	"     LLLLLLLLLLLLLLLLLLL      \n"
	"     LLLLLLLLLLLLLLLLLLL      \n"
	"\n");

	getchar(); //Pause program
	return 0;
}

